#!/usr/bin/env python3
"""
Simple Flask app for Cloud Run email processing
"""

import os
import json
from flask import Flask, request, jsonify
from production_screenshot_gpt import EmailProcessor

app = Flask(__name__)

@app.route('/')
def hello():
    return jsonify({
        "status": "running",
        "service": "email-analytics-pipeline",
        "version": "fixed-all-mailboxes"
    })

@app.route('/process', methods=['POST'])
def process_emails():
    """Process emails with fixed settings"""
    try:
        # Initialize processor with fixed settings
        processor = EmailProcessor()
        
        # Process emails
        processor.process_emails(days_back=3)
        
        return jsonify({
            "status": "success",
            "message": "Email processing completed with fixed settings",
            "features": [
                "ALL 68 mailboxes processed",
                "ALL folders checked (inbox, spam, junk)",
                "500 emails per folder (vs 50)",
                "3-day lookback (vs 1 day)",
                "Lowered detection threshold"
            ]
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

@app.route('/health')
def health_check():
    return jsonify({"status": "healthy"})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=False) 