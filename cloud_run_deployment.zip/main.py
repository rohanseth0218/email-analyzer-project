#!/usr/bin/env python3
"""
Main entry point for Cloud Run email processing service
"""

import os
import sys
from production_screenshot_gpt import EmailProcessor, CONFIG

def main():
    """Main function for Cloud Run"""
    print("🚀 Starting Cloud Run Email Processing Service")
    
    # Initialize processor
    processor = EmailProcessor()
    
    # Start processing emails
    processor.process_emails(days_back=3)
    
    print("✅ Email processing completed")

if __name__ == "__main__":
    main() 