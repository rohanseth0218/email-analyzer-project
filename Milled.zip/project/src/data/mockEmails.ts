import { EmailCampaign } from '../types/email';

export const mockEmails: EmailCampaign[] = [
  {
    id: '1',
    brand: 'PACSUN',
    subject: 'Weekend Sale - Thousands of Styles Starting at $15',
    date: '2024-06-15',
    screenshot: 'https://images.pexels.com/photos/6975474/pexels-photo-6975474.jpeg?auto=compress&cs=tinysrgb&w=400&h=800',
    campaign_theme: 'product promotion',
    design_level: 'Advanced',
    discount_percent: 25,
    emotional_tone: 'energetic, promotional',
    event_or_seasonality: 'Weekend Sale',
    flow_type: null,
    flow_vs_campaign: 'campaign',
    image_vs_text_ratio: 0.6,
    num_products_featured: 3,
    personalization_used: false,
    social_proof_used: true,
    unsubscribe_visible: true,
    visual_content: [
      {
        block_index: 0,
        columns: null,
        copy: 'PACSUN',
        cta: null,
        desc: 'Displays the PACSUN logo prominently at the top of the email.',
        has_button: false,
        has_image: false,
        role: 'Logo',
        style: 'Centered logo with black text on a white background.'
      },
      {
        block_index: 1,
        columns: null,
        copy: 'THOUSANDS OF STYLES STARTING AT $15 $20 $25',
        cta: null,
        desc: 'Bold promotional banner with pricing tiers.',
        has_button: false,
        has_image: true,
        role: 'Hero',
        style: 'Red background with white text and pricing callouts.'
      }
    ]
  },
  {
    id: '2',
    brand: 'Mimco',
    subject: 'Take a further 20% off sale - Ends Tonight',
    date: '2024-06-15',
    screenshot: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400&h=800',
    campaign_theme: 'product promotion',
    design_level: 'Expert',
    discount_percent: 20,
    emotional_tone: 'urgent, elegant',
    event_or_seasonality: 'Sale End',
    flow_type: null,
    flow_vs_campaign: 'campaign',
    image_vs_text_ratio: 0.7,
    num_products_featured: 4,
    personalization_used: true,
    social_proof_used: false,
    unsubscribe_visible: true,
    visual_content: [
      {
        block_index: 0,
        columns: null,
        copy: 'MIMCO',
        cta: null,
        desc: 'Mimco logo with elegant typography',
        has_button: false,
        has_image: true,
        role: 'Logo',
        style: 'Clean logo on white background'
      }
    ]
  },
  {
    id: '3',
    brand: 'Gucci',
    subject: 'Denim in Focus - Accenting everyday looks',
    date: '2024-06-15',
    screenshot: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400&h=800',
    campaign_theme: 'product launch',
    design_level: 'Expert',
    discount_percent: null,
    emotional_tone: 'luxury, sophisticated',
    event_or_seasonality: null,
    flow_type: null,
    flow_vs_campaign: 'campaign',
    image_vs_text_ratio: 0.85,
    num_products_featured: 1,
    personalization_used: false,
    social_proof_used: false,
    unsubscribe_visible: true,
    visual_content: [
      {
        block_index: 0,
        columns: null,
        copy: 'GUCCI',
        cta: null,
        desc: 'Luxury Gucci branding',
        has_button: false,
        has_image: true,
        role: 'Logo',
        style: 'Elegant serif typography'
      }
    ]
  },
  {
    id: '4',
    brand: 'Maurie and Eve',
    subject: 'Up to 60% Off - Shop Now',
    date: '2024-06-15',
    screenshot: 'https://images.pexels.com/photos/164938/pexels-photo-164938.jpeg?auto=compress&cs=tinysrgb&w=400&h=800',
    campaign_theme: 'product promotion',
    design_level: 'Advanced',
    discount_percent: 60,
    emotional_tone: 'elegant, promotional',
    event_or_seasonality: 'Sale',
    flow_type: null,
    flow_vs_campaign: 'campaign',
    image_vs_text_ratio: 0.8,
    num_products_featured: 2,
    personalization_used: false,
    social_proof_used: false,
    unsubscribe_visible: true,
    visual_content: [
      {
        block_index: 0,
        columns: null,
        copy: 'Maurie and Eve',
        cta: null,
        desc: 'Elegant brand logo with script typography',
        has_button: false,
        has_image: true,
        role: 'Logo',
        style: 'Script font on clean background'
      }
    ]
  },
  {
    id: '5',
    brand: 'Nike',
    subject: 'Just Do It - New Air Max Collection',
    date: '2024-06-14',
    screenshot: 'https://images.pexels.com/photos/1320684/pexels-photo-1320684.jpeg?auto=compress&cs=tinysrgb&w=400&h=800',
    campaign_theme: 'product launch',
    design_level: 'Expert',
    discount_percent: 20,
    emotional_tone: 'energetic, aspirational',
    event_or_seasonality: 'New Collection',
    flow_type: null,
    flow_vs_campaign: 'campaign',
    image_vs_text_ratio: 0.8,
    num_products_featured: 3,
    personalization_used: true,
    social_proof_used: true,
    unsubscribe_visible: true,
    visual_content: [
      {
        block_index: 0,
        columns: null,
        copy: 'NIKE',
        cta: null,
        desc: 'Nike swoosh logo prominently displayed',
        has_button: false,
        has_image: true,
        role: 'Logo',
        style: 'Black swoosh on white background'
      }
    ]
  },
  {
    id: '6',
    brand: 'Apple',
    subject: 'iPhone 15 Pro - Titanium. So strong. So light.',
    date: '2024-06-13',
    screenshot: 'https://images.pexels.com/photos/919073/pexels-photo-919073.jpeg?auto=compress&cs=tinysrgb&w=400&h=800',
    campaign_theme: 'product announcement',
    design_level: 'Expert',
    discount_percent: null,
    emotional_tone: 'premium, sophisticated',
    event_or_seasonality: null,
    flow_type: null,
    flow_vs_campaign: 'campaign',
    image_vs_text_ratio: 0.9,
    num_products_featured: 1,
    personalization_used: false,
    social_proof_used: false,
    unsubscribe_visible: true,
    visual_content: [
      {
        block_index: 0,
        columns: null,
        copy: 'Apple',
        cta: null,
        desc: 'Minimalist Apple logo',
        has_button: false,
        has_image: true,
        role: 'Logo',
        style: 'Simple black Apple logo on white'
      }
    ]
  },
  {
    id: '7',
    brand: 'Spotify',
    subject: 'Your 2024 Wrapped is here!',
    date: '2024-06-12',
    screenshot: 'https://images.pexels.com/photos/164938/pexels-photo-164938.jpeg?auto=compress&cs=tinysrgb&w=400&h=800',
    campaign_theme: 'personalized content',
    design_level: 'Advanced',
    discount_percent: null,
    emotional_tone: 'playful, nostalgic',
    event_or_seasonality: 'Year End',
    flow_type: null,
    flow_vs_campaign: 'campaign',
    image_vs_text_ratio: 0.6,
    num_products_featured: 0,
    personalization_used: true,
    social_proof_used: true,
    unsubscribe_visible: true,
    visual_content: [
      {
        block_index: 0,
        columns: null,
        copy: 'Spotify',
        cta: null,
        desc: 'Spotify logo with gradient background',
        has_button: false,
        has_image: true,
        role: 'Logo',
        style: 'Green logo on dark gradient'
      }
    ]
  },
  {
    id: '8',
    brand: 'Tesla',
    subject: 'Model 3 - Now with Enhanced Autopilot',
    date: '2024-06-11',
    screenshot: 'https://images.pexels.com/photos/919073/pexels-photo-919073.jpeg?auto=compress&cs=tinysrgb&w=400&h=800',
    campaign_theme: 'feature update',
    design_level: 'Expert',
    discount_percent: null,
    emotional_tone: 'futuristic, innovative',
    event_or_seasonality: null,
    flow_type: null,
    flow_vs_campaign: 'campaign',
    image_vs_text_ratio: 0.75,
    num_products_featured: 1,
    personalization_used: false,
    social_proof_used: false,
    unsubscribe_visible: true,
    visual_content: [
      {
        block_index: 0,
        columns: null,
        copy: 'TESLA',
        cta: null,
        desc: 'Tesla logo in sleek typography',
        has_button: false,
        has_image: false,
        role: 'Logo',
        style: 'Red text on white background'
      }
    ]
  }
];