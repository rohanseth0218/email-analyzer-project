import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Header } from './components/Header';
import { FilterBar } from './components/FilterBar';
import { EmailCard } from './components/EmailCard';
import { EmailDrawer } from './components/EmailDrawer';
import { mockEmails } from './data/mockEmails';
import { EmailCampaign, FilterOptions } from './types/email';
import { Search } from 'lucide-react';

function App() {
  const [selectedEmail, setSelectedEmail] = useState<EmailCampaign | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<FilterOptions>({
    brand: 'All Brands',
    dateRange: 'All Time',
    theme: 'All Themes',
    designLevel: 'All Levels'
  });

  const filteredEmails = useMemo(() => {
    return mockEmails.filter(email => {
      // Search filter
      if (searchQuery && !email.brand.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !email.subject.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !email.campaign_theme.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }

      // Brand filter
      if (filters.brand !== 'All Brands' && email.brand !== filters.brand) {
        return false;
      }

      // Theme filter
      if (filters.theme !== 'All Themes' && email.campaign_theme !== filters.theme) {
        return false;
      }

      // Date range filter (simplified for demo)
      if (filters.dateRange !== 'All Time') {
        const emailDate = new Date(email.date);
        const now = new Date();
        const daysDiff = Math.floor((now.getTime() - emailDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (filters.dateRange === 'Last 7 days' && daysDiff > 7) return false;
        if (filters.dateRange === 'Last 30 days' && daysDiff > 30) return false;
        if (filters.dateRange === 'This Year' && emailDate.getFullYear() !== now.getFullYear()) return false;
      }

      return true;
    });
  }, [searchQuery, filters]);

  const handleEmailClick = (email: EmailCampaign) => {
    setSelectedEmail(email);
    setIsDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false);
    setTimeout(() => setSelectedEmail(null), 300);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <FilterBar 
        filters={filters}
        onFiltersChange={setFilters}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />
      
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Results count */}
        <motion.div 
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-gray-700 text-lg">
            <span className="font-semibold text-gray-900">{filteredEmails.length}</span> email campaigns
          </p>
        </motion.div>

        {/* Email Grid - Milled Style */}
        <AnimatePresence mode="wait">
          {filteredEmails.length > 0 ? (
            <motion.div 
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              {filteredEmails.map((email, index) => (
                <motion.div
                  key={email.id}
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                >
                  <EmailCard
                    email={email}
                    onClick={() => handleEmailClick(email)}
                  />
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div 
              className="text-center py-24"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <div className="w-32 h-32 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-8">
                <Search className="w-16 h-16 text-gray-400" />
              </div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">No campaigns found</h3>
              <p className="text-gray-600 max-w-md mx-auto text-lg leading-relaxed">
                Try adjusting your search criteria or filters to discover more email campaigns.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Email Drawer */}
      <EmailDrawer
        email={selectedEmail}
        isOpen={isDrawerOpen}
        onClose={handleCloseDrawer}
      />
    </div>
  );
}

export default App;